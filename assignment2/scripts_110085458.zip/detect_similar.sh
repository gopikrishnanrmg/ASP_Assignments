# Author: Gopikrishnan Rajeev
# ID: 110085458

#!/bin/bash
if [ $# -lt 1 ]	#Check if hash has been passed as argument else exit after displaying message
then
	echo "Not enough arguments"
	exit
fi

searchHash=$1	#Fetch the hash to be searched with
declare -A array	#Array to store mapping filePath->Owner
declare -a ignoreList	#unset method cannot update the iteration on the iterated array once looping is already taking place, so we use an ignoreList to ignore values
count=0

while read line	#Fetch the piped values from sum_md5.sh
do
	IFS=':'	#Parse the value being passed using ":" as the seperator
	read -ra newarr <<< "$line"	#Split the input to array form using ":" as the delim and assign to corresponding variables
	path=${newarr[0]}
	owner=${newarr[1]}
	hash=${newarr[2]}
	if [ "$hash" == "$searchHash" ]	#If the hash of the file matches the hash to be searched for, then add to the array creating a map filepath=>owner using associative array method
	then
		((count++))
		array+=([$path]=$owner)
	fi
done


for key in "${!array[@]}"	#For each iteration of this, we try to deal with files having the same owner
do
	ignore=0
	for check in "${ignoreList[@]}"	#Check if current input is in ignoreList, if yes it means the value was already accounted for
	do
		if [ "$key" == "$check" ]
		then
			ignore=1;
			break
		fi
	done
	
	if [ $ignore -eq 1 ]	#If found in ignoreList then skip the current iteration and continue with next iteration
	then
		continue
	fi
	
	declare -A fileNameArray	#Array to track names of files, used for incrementing the extension in the case of duplicate names
	declare -A finalArray	#Array responsible for the final output
	tempFile=$key
	tempOwner=${array[$key]}
	fileNameArray+=([$(basename $tempFile)]=1)	#As this is the first value for a particular owner being taken for the major iteration, increment it's basename to 1	
	finalArray+=([$tempFile]=$(basename $tempFile))	#Add this value to the finalArray
	ignoreList+=($tempFile)	#Add to ignoreList as we already are accounting for this value
	flag=0
	
	for j in "${!array[@]}"	#Check the remaining entries having same owner
	do
		if [ "$tempOwner" == "${array[$j]}" ]	#If owner the matches
		then
			ignore=0
			for check in "${ignoreList[@]}" #Check if current input is in ignoreList, if yes it means the value was already accounted for and processed
			do
				if [ "$j" == "$check" ]
				then
					ignore=1;
					break
				fi
			done

			if [ $ignore -eq 1 ]
			then
				continue
			fi
			flag=1	#Found at least 1 file which has similar hash
			fileBasename=$(basename $j)
			if [ -z "${fileNameArray[$fileBasename]}" ]	#If basename has no duplicate then increment the filecount and add to the array for tracking, if it already has a duplicate value accounted, then increment and update the fileNameArray
			then
				fileCount=0
			else
				fileCount="${fileNameArray[$fileBasename]}"
			fi
			finalArray+=([$j]=$fileBasename)
			((fileCount++))
			fileNameArray+=([$fileBasename]=$fileCount)
			ignoreList+=($j)	#Add to ignoreList as the entry was already processed
		fi
	done

	
	for j in "${!fileNameArray[@]}" #Reset all the non duplicate values to 0, these are names which we don't want to increment, so we give it 0 for being ignored in the following code which deals with increment
	do
		if [ ${fileNameArray[$j]} -eq 1 ]
		then
			fileNameArray+=([$j]=0) #Reset the value to 0 if its 1
		fi
	done
	
	
	if [ $flag -eq 1 ]
	then
		echo "[$1]" #Print format as needed by the task
		for j in "${!finalArray[@]}"
		do
			cnt=${fileNameArray[${finalArray[$j]}]} #Fetch the occurance of duplicate basename
			if [ $cnt -gt 0 ]	#If there are duplicate entries with same name we update the names of the files by increment operation
			then
				fileName=${finalArray[$j]}	#Fetch file name
				extension="${fileName##*.}"	#Fetch the extension of the file
				fileName="${fileName%.*}"	#Fetch the filename without the extension
				filePath=$(dirname $j)	#Fetch parent folder
				echo "$filePath/$fileName$cnt.$extension -> $fileName$cnt.$extension"
				((cnt--))	#Decrement the count already issued for a file
				fileNameArray+=([${finalArray[$j]}]=$cnt)	#Update the count of the duplicate name in the fileNameArray
			else
				echo "$j -> ${finalArray[$j]}"	#If no duplicate name then display regularly
			fi

			unset finalArray[$j]	#Reset the entries of finalArray
		done
	fi
	unset fileNameArray	#Reset the fileNameArray
done
