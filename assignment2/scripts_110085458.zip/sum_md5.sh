# Author: Gopikrishnan Rajeev
# ID: 110085458

#!/bin/bash
find $1 -print |	#Find all files in $1 if empty use current folder
while read -r line	#Read each entry
do
	filepath=$line	
	if [ -d "$filepath" ]	#If file is a folder then ignore and continue with iteration
	then
		continue
	fi
	hash=($(md5sum "$filepath"))	#Get the hash of the file
	owner=$(stat -c "%U" "$filepath")	#Get the owner using stat on the file
	echo $filepath:$owner:$hash	#Print the output as required by the task
done

