# Author: Gopikrishnan Rajeev
# ID: 110085458

#!/bin/bash
if [ $# -lt 2 ]	#Check if arguments have been passed else exit after displaying message
then
	echo "Not enough arguments"
	exit
fi

if [ $2 != "-d" ]	#Check if -d argument have been passed else exit after displaying message
then
	echo "No -d flag detected"
	exit
fi

user=$(whoami)	#Fetch current user's name
searchFile=$1	#Fetch file to be searched
destination=$3	#Fetch the destination for creating the md5 folder
count=0	#Variable to track the number of files copied

if [ -w "$3" ]	#Check if destination is writable else exit after displaying message
then
	:
else
	echo "Destination not writable"
	exit
fi

searchFileHash=($(md5sum $1))	#Calculate the hash of the file to be searched
destination="$destination$searchFileHash"	#Final Destination to write the output

$(mkdir "$destination" )	#Create the folder
if [ $? -eq 0 ]
then
	:
else
	echo "Cannot create folder $destination"
    	exit
fi

lines=$(./sum_md5.sh | ./detect_similar.sh $searchFileHash)	#Call other scripts to fetch all the files with matching md5 hashes in the current folder
while read line	#To parse each line and fetch the details
do
	filePath=$(echo "$line" | grep "/")	#Fetch only lines having folder details

	if [ -z "$filePath" ]	#Ignore lines without "/" which are not path
	then
		:
	else
		delimiter=" ->"	#Delimit using " ->" to parse the filePath
		filePath="${filePath%%"$delimiter"*}"	#Fetch the file's path
		
		owner=$(stat -c "%U" "$filePath" 2>/dev/null)	#Find the owner of the file, if the file was incremented by a number in detect_similar.sh this would fail, so don't display the error, it will be dealt in the following code
        	if [ $? -eq 0 ]
    		then
			originalFilePath="$filePath"	#Successfully fetched the owner as the file was not incremented			
		else					#File was incremented, so we need to reconstruct the original filename after removing the increment value
			parentName=$(dirname "$filePath") #Fetch parent folder	
			fileName=$(basename "$filePath")	#Fetch the file's basename
			extension="${fileName##*.}"	#Fetch the extension of the file
			fileName="${fileName%.*}"	#Fetch the filename without the extension
			fileName=${fileName%?}	#Remove the incremented value to retrive original name
			originalFilePath="$parentName/$fileName.$extension"	#Reconstruct the original file's location
			owner=$(stat -c "%U" "$originalFilePath" 2>/dev/null)	#Fetch the owner details of the file
    		fi
    		
    		if [ $owner == $user ]	#If the owner is same as the user running the script
    		then
    			#echo $owner
    			((count++))	#Increment number of files being found and copied
    			
    				$(cp "$originalFilePath" "$destination/$(basename "$filePath")")	#Copy the file to the destination while preserving the naming with increment details
    				if [ $? -eq 0 ]	#If the copy command is successful continue else exit after displaying the error
    				then
    					:
    				else
    					echo "Cannot copy $originalFilePath to $destination/$(basename "$filePath")"
    					exit
    				fi
    		fi
	fi
done <<< "$lines"

echo "Number of identical files to filename: $count"
